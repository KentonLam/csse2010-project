void init_joystick();
uint8_t get_joystick_input();