/*
 * sort.h
 *
 * Created: 20/05/2019 10:59:23 PM
 *  Author: Kenton
 */ 


#ifndef SORT_H_
#define SORT_H_


void asteroid_sort(uint8_t *array, uint8_t numAsteroids);


#endif /* SORT_H_ */